package com.example.springbootplus.service.impl;

import com.example.springbootplus.entity.OperaterLog;
import com.example.springbootplus.mapper.OperaterLogMapper;
import com.example.springbootplus.service.OperaterLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author code946
 * @since 2022-04-15
 */
@Service
public class OperaterLogServiceImpl extends ServiceImpl<OperaterLogMapper, OperaterLog> implements OperaterLogService {

}
