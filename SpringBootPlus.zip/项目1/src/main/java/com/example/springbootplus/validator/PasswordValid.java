package com.example.springbootplus.validator;

public interface PasswordValid {
}
