package com.example.springbootplus.service.impl;

import com.example.springbootplus.entity.User;
import com.example.springbootplus.mapper.UserMapper;
import com.example.springbootplus.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author code946
 * @since 2022-04-15
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

}
