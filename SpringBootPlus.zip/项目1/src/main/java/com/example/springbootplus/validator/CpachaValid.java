package com.example.springbootplus.validator;

public class CpachaValid {
}
