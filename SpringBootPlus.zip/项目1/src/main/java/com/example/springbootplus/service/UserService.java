package com.example.springbootplus.service;

import com.example.springbootplus.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author code946
 * @since 2022-04-15
 */
public interface UserService extends IService<User> {

}
