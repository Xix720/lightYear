package com.example.springbootplus.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author code946
 * @since 2022-04-15
 */
@RestController
@RequestMapping("/role-authorities")
public class RoleAuthoritiesController {

}

