package com.example.springbootplus.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.springbootplus.entity.OperaterLog;
import com.example.springbootplus.service.OperaterLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author code946
 * @since 2022-04-15
 */
@Controller
@RequestMapping("/log")
public class OperaterLogController {
    @Autowired
    private OperaterLogService operaterLogService;

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public String list(@RequestParam(defaultValue = "1") Long current, Model model){

        IPage<OperaterLog> pageParam = new Page<>(current,10);
        IPage<OperaterLog> logPage = operaterLogService.page(pageParam,new QueryWrapper<OperaterLog>().orderByDesc("id"));

        model.addAttribute("logPage",logPage);

        return "/admin/log/list";
    }
}

